import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  Search, PlusCircle, Presentation, MapPin, Tag, Calendar, 
  CheckCircle2, AlertTriangle, ShieldCheck, HelpCircle, 
  ExternalLink, Download, ChevronLeft, ChevronRight, X, 
  RefreshCw, Check, Sparkles, Filter, Building2, Phone, Mail, Award
} from 'lucide-react';

const API_BASE = 'http://localhost:5001/api';

const CATEGORIES = [
  'All Categories',
  'Electronics',
  'Cards & IDs',
  'Books & Stationary',
  'Keys & Accessories',
  'Lab & Clothing',
  'Personal Items'
];

const CAMPUS_LOCATIONS = [
  'All Locations',
  'Central Library',
  'Main Cafeteria',
  'Computer Center',
  'Mechanical Block',
  'Chemistry Science Block',
  'Sports Complex',
  'Auditorium',
  'Parking Bay B'
];

export default function App() {
  const [items, setItems] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    activeLost: 0,
    activeFound: 0,
    returnedCount: 0,
    recoveryRate: 0,
    categoryStats: {},
    locationStats: {}
  });
  
  // Filter States
  const [search, setSearch] = useState('');
  const [selectedType, setSelectedType] = useState('all'); // all, lost, found
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [selectedLocation, setSelectedLocation] = useState('All Locations');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [loading, setLoading] = useState(true);

  // Modals
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [isPresentationOpen, setIsPresentationOpen] = useState(false);
  
  // Presentation State
  const [slides, setSlides] = useState([]);
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [showSpeakerNotes, setShowSpeakerNotes] = useState(true);

  // Claim Form State
  const [claimName, setClaimName] = useState('');
  const [claimContact, setClaimContact] = useState('');
  const [claimProof, setClaimProof] = useState('');
  const [submittingClaim, setSubmittingClaim] = useState(false);

  // Report Form State
  const [reportData, setReportData] = useState({
    title: '',
    type: 'found',
    category: 'Electronics',
    location: 'Central Library',
    date: new Date().toISOString().split('T')[0],
    description: '',
    contactName: '',
    contactInfo: '',
    verificationQuestion: '',
    presetImage: ''
  });
  const [submittingReport, setSubmittingReport] = useState(false);

  // Toast
  const [toast, setToast] = useState(null);

  const showToast = (message) => {
    setToast(message);
    setTimeout(() => setToast(null), 3500);
  };

  const triggerCelebration = () => {
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // fallback
    }
  };

  // Fetch Items
  const fetchItems = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedType !== 'all') params.append('type', selectedType);
      if (selectedCategory !== 'All Categories') params.append('category', selectedCategory);
      if (selectedLocation !== 'All Locations') params.append('location', selectedLocation);
      if (selectedStatus !== 'all') params.append('status', selectedStatus);
      if (search.trim()) params.append('search', search.trim());

      const res = await fetch(`${API_BASE}/items?${params.toString()}`);
      const data = await res.json();
      setItems(data.items || []);
    } catch (err) {
      console.error('Failed to fetch items:', err);
      showToast('Could not connect to backend server. Make sure port 5001 is running.');
    } finally {
      setLoading(false);
    }
  };

  // Fetch Stats
  const fetchStats = async () => {
    try {
      const res = await fetch(`${API_BASE}/stats`);
      const data = await res.json();
      setStats(data);
    } catch (err) {
      console.error('Failed to fetch stats:', err);
    }
  };

  // Fetch Slides
  const fetchSlides = async () => {
    try {
      const res = await fetch(`${API_BASE}/presentation/slides`);
      const data = await res.json();
      setSlides(data.slides || []);
    } catch (err) {
      console.error('Failed to fetch presentation slides:', err);
    }
  };

  useEffect(() => {
    fetchItems();
  }, [selectedType, selectedCategory, selectedLocation, selectedStatus, search]);

  useEffect(() => {
    fetchStats();
    fetchSlides();
  }, []);

  // Submit Claim
  const handleClaimSubmit = async (e) => {
    e.preventDefault();
    if (!claimName || !claimContact || !claimProof) {
      alert('Please fill in all claim details');
      return;
    }

    setSubmittingClaim(true);
    try {
      const res = await fetch(`${API_BASE}/items/${selectedItem.id}/claim`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          claimantName: claimName,
          claimantContact: claimContact,
          proofAnswer: claimProof
        })
      });
      const data = await res.json();
      if (res.ok) {
        showToast('Claim submitted! Poster has been notified with your proof.');
        triggerCelebration();
        setSelectedItem(data.item);
        setClaimName('');
        setClaimContact('');
        setClaimProof('');
        fetchItems();
        fetchStats();
      } else {
        alert(data.error || 'Failed to submit claim');
      }
    } catch (err) {
      alert('Network error while submitting claim');
    } finally {
      setSubmittingClaim(false);
    }
  };

  // Update Status
  const handleUpdateStatus = async (itemId, newStatus) => {
    try {
      const res = await fetch(`${API_BASE}/items/${itemId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        const data = await res.json();
        showToast(`Item status marked as: ${newStatus.toUpperCase()}`);
        if (newStatus === 'returned') triggerCelebration();
        fetchItems();
        fetchStats();
        if (selectedItem && selectedItem.id === itemId) {
          setSelectedItem(data.item);
        }
      }
    } catch (err) {
      alert('Error updating status');
    }
  };

  // Submit Report
  const handleReportSubmit = async (e) => {
    e.preventDefault();
    setSubmittingReport(true);
    try {
      const res = await fetch(`${API_BASE}/items`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reportData)
      });
      if (res.ok) {
        showToast('Item posted successfully to Campus Notice Feed!');
        triggerCelebration();
        setIsReportOpen(false);
        setReportData({
          title: '',
          type: 'found',
          category: 'Electronics',
          location: 'Central Library',
          date: new Date().toISOString().split('T')[0],
          description: '',
          contactName: '',
          contactInfo: '',
          verificationQuestion: '',
          presetImage: ''
        });
        fetchItems();
        fetchStats();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to report item');
      }
    } catch (err) {
      alert('Error submitting item');
    } finally {
      setSubmittingReport(false);
    }
  };

  return (
    <div>
      {/* Toast Notification */}
      {toast && (
        <div className="toast-container">
          <div className="toast">
            <Sparkles size={18} color="#38bdf8" />
            <span>{toast}</span>
          </div>
        </div>
      )}

      {/* Navigation */}
      <header className="navbar">
        <div className="nav-brand" onClick={() => { setSelectedType('all'); setSelectedCategory('All Categories'); }}>
          <div className="brand-icon">
            <Building2 size={24} />
          </div>
          <div className="brand-text">
            <h1>CampusFind</h1>
            <p>Smart Item Recovery System</p>
          </div>
        </div>

        <div className="nav-actions">
          <button 
            className="btn btn-presentation"
            onClick={() => setIsPresentationOpen(true)}
          >
            <Presentation size={17} />
            <span>Project Presentation</span>
          </button>

          <a 
            href={`${API_BASE}/presentation/download`} 
            className="btn btn-secondary"
            title="Download PowerPoint PPTX"
          >
            <Download size={16} />
            <span>Download .PPTX</span>
          </a>

          <button 
            className="btn btn-primary"
            onClick={() => setIsReportOpen(true)}
          >
            <PlusCircle size={18} />
            <span>Report Item</span>
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-content">
          <div className="hero-badge">
            <ShieldCheck size={14} />
            <span>CAMPUS DIGITAL RECOVERY NETWORK</span>
          </div>
          <h2 className="hero-title">
            Lost Something on Campus? <br />
            <span>Find & Reclaim it Safely.</span>
          </h2>
          <p className="hero-desc">
            A centralized, dynamic recovery hub replacing noisy group chats with 
            verified ownership proof, instant location filtering, and campus-wide resolution tracking.
          </p>

          {/* Dynamic Stats Grid */}
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-icon blue">
                <Tag size={22} />
              </div>
              <div className="stat-info">
                <div className="stat-num">{stats.total || items.length}</div>
                <div className="stat-label">Total Listings</div>
              </div>
            </div>

            <div className="stat-card">
              <div className="stat-icon red">
                <AlertTriangle size={22} />
              </div>
              <div className="stat-info">
                <div className="stat-num">{stats.activeLost || 0}</div>
                <div className="stat-label">Active Lost</div>
              </div>
            </div>

            <div className="stat-card">
              <div className="stat-icon green">
                <CheckCircle2 size={22} />
              </div>
              <div className="stat-info">
                <div className="stat-num">{stats.activeFound || 0}</div>
                <div className="stat-label">Items Found</div>
              </div>
            </div>

            <div className="stat-card">
              <div className="stat-icon amber">
                <Award size={22} />
              </div>
              <div className="stat-info">
                <div className="stat-num">{stats.recoveryRate || 82}%</div>
                <div className="stat-label">Recovery Rate</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Dynamic Controls Bar */}
      <div className="controls-bar">
        {/* Type Filter Tabs */}
        <div className="type-tabs">
          <button 
            className={`type-tab ${selectedType === 'all' ? 'active' : ''}`}
            onClick={() => setSelectedType('all')}
          >
            All Items
          </button>
          <button 
            className={`type-tab ${selectedType === 'found' ? 'active' : ''}`}
            onClick={() => setSelectedType('found')}
          >
            🟢 Found Items
          </button>
          <button 
            className={`type-tab ${selectedType === 'lost' ? 'active' : ''}`}
            onClick={() => setSelectedType('lost')}
          >
            🔴 Lost Items
          </button>
        </div>

        {/* Instant Search Box */}
        <div className="search-box">
          <Search size={18} className="search-icon" />
          <input 
            type="text" 
            className="search-input"
            placeholder="Search by item name, details, or keywords..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {/* Select Dropdowns */}
        <div className="filter-selects">
          <select 
            className="select-input"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            {CATEGORIES.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          <select 
            className="select-input"
            value={selectedLocation}
            onChange={(e) => setSelectedLocation(e.target.value)}
          >
            {CAMPUS_LOCATIONS.map(loc => (
              <option key={loc} value={loc}>{loc}</option>
            ))}
          </select>

          <select 
            className="select-input"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
          >
            <option value="all">All Statuses</option>
            <option value="active">Active Only</option>
            <option value="claimed">Claim Pending</option>
            <option value="returned">Resolved / Returned</option>
          </select>
        </div>
      </div>

      {/* Main Items Section */}
      <main className="items-section">
        <div className="feed-header">
          <h3 className="feed-title">
            {selectedType === 'lost' ? 'Reported Lost Items' : selectedType === 'found' ? 'Reported Found Items' : 'All Campus Listings'}
          </h3>
          <div className="feed-count">
            Showing <strong>{items.length}</strong> items
          </div>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '4rem 1rem', color: '#64748b' }}>
            <RefreshCw size={32} className="spin" style={{ animation: 'spin 1s linear infinite' }} />
            <p style={{ marginTop: '0.75rem', fontWeight: 600 }}>Loading campus reports...</p>
          </div>
        ) : items.length === 0 ? (
          <div style={{ 
            textAlign: 'center', 
            padding: '4rem 2rem', 
            background: 'white', 
            borderRadius: '16px', 
            border: '1px dashed #cbd5e1' 
          }}>
            <HelpCircle size={48} color="#94a3b8" style={{ marginBottom: '1rem' }} />
            <h4 style={{ fontSize: '1.2rem', color: '#0f172a', marginBottom: '0.5rem' }}>No Matching Items Found</h4>
            <p style={{ color: '#64748b', fontSize: '0.9rem', maxWidth: '420px', margin: '0 auto 1.5rem' }}>
              No campus records match your current filters. Try resetting search filters or report a new lost/found item.
            </p>
            <button 
              className="btn btn-primary"
              onClick={() => {
                setSearch('');
                setSelectedType('all');
                setSelectedCategory('All Categories');
                setSelectedLocation('All Locations');
                setSelectedStatus('all');
              }}
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="items-grid">
            {items.map(item => (
              <div key={item.id} className="item-card">
                <div className="card-image-wrap">
                  <img src={item.imageUrl} alt={item.title} className="card-img" />
                  <span className={`badge-type ${item.type}`}>
                    {item.type}
                  </span>
                  <span className={`badge-status ${item.status}`}>
                    {item.status}
                  </span>
                </div>

                <div className="card-body">
                  <div className="card-meta-top">
                    <span className="card-category">{item.category}</span>
                    <span className="card-date">{item.date}</span>
                  </div>

                  <h4 className="card-title">{item.title}</h4>

                  <div className="card-location">
                    <MapPin size={14} color="#64748b" />
                    <span>{item.location}</span>
                  </div>

                  <p className="card-desc">{item.description}</p>

                  {item.verificationQuestion && (
                    <div className="card-security-hint">
                      <strong>Verification Required:</strong> {item.verificationQuestion}
                    </div>
                  )}

                  <div className="card-actions">
                    <button 
                      className="btn btn-primary" 
                      style={{ flex: 1 }}
                      onClick={() => setSelectedItem(item)}
                    >
                      {item.type === 'found' ? 'Claim This Item' : 'View / Provide Lead'}
                    </button>

                    {item.status !== 'returned' && (
                      <button 
                        className="btn btn-secondary"
                        title="Mark as Returned / Resolved"
                        onClick={() => handleUpdateStatus(item.id, 'returned')}
                      >
                        <Check size={16} />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Item Detail & Claim Modal */}
      {selectedItem && (
        <div className="modal-overlay" onClick={() => setSelectedItem(null)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{selectedItem.title}</h2>
              <button className="modal-close-btn" onClick={() => setSelectedItem(null)}>
                <X size={20} />
              </button>
            </div>

            <div className="modal-body">
              <div style={{ display: 'flex', gap: '1.25rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
                <img 
                  src={selectedItem.imageUrl} 
                  alt={selectedItem.title} 
                  style={{ width: '180px', height: '140px', objectFit: 'cover', borderRadius: '12px' }} 
                />
                <div style={{ flex: 1, minWidth: '220px' }}>
                  <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem' }}>
                    <span className={`badge-type ${selectedItem.type}`} style={{ position: 'static' }}>
                      {selectedItem.type.toUpperCase()}
                    </span>
                    <span className={`badge-status ${selectedItem.status}`} style={{ position: 'static' }}>
                      STATUS: {selectedItem.status.toUpperCase()}
                    </span>
                  </div>
                  <p style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>
                    <strong>Category:</strong> {selectedItem.category}
                  </p>
                  <p style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>
                    <strong>Location:</strong> {selectedItem.location}
                  </p>
                  <p style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '0.25rem' }}>
                    <strong>Date Reported:</strong> {selectedItem.date}
                  </p>
                  <p style={{ fontSize: '0.875rem', color: '#64748b' }}>
                    <strong>Reported by:</strong> {selectedItem.contactName} ({selectedItem.contactInfo})
                  </p>
                </div>
              </div>

              <div style={{ marginBottom: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: '12px' }}>
                <h4 style={{ fontSize: '0.9rem', marginBottom: '0.35rem', color: '#0f172a' }}>Item Description</h4>
                <p style={{ fontSize: '0.875rem', color: '#475569', lineHeight: 1.5 }}>{selectedItem.description}</p>
              </div>

              {/* Security Verification Box */}
              {selectedItem.verificationQuestion && (
                <div style={{ 
                  background: '#eff6ff', 
                  border: '1px solid #bfdbfe', 
                  borderRadius: '12px', 
                  padding: '1rem', 
                  marginBottom: '1.5rem' 
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#1e40af', fontWeight: 700, fontSize: '0.9rem', marginBottom: '0.35rem' }}>
                    <ShieldCheck size={18} />
                    <span>Proof of Ownership Challenge</span>
                  </div>
                  <p style={{ fontSize: '0.875rem', color: '#1e3a8a' }}>
                    "{selectedItem.verificationQuestion}"
                  </p>
                </div>
              )}

              {/* Status Action Buttons */}
              <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.5rem' }}>
                <button 
                  className={`btn ${selectedItem.status === 'active' ? 'btn-primary' : 'btn-secondary'}`}
                  onClick={() => handleUpdateStatus(selectedItem.id, 'active')}
                >
                  Mark Active
                </button>
                <button 
                  className={`btn ${selectedItem.status === 'claimed' ? 'btn-primary' : 'btn-secondary'}`}
                  onClick={() => handleUpdateStatus(selectedItem.id, 'claimed')}
                >
                  Mark Claim Pending
                </button>
                <button 
                  className={`btn ${selectedItem.status === 'returned' ? 'btn-primary' : 'btn-secondary'}`}
                  style={{ background: selectedItem.status === 'returned' ? '#10b981' : '', color: selectedItem.status === 'returned' ? 'white' : '' }}
                  onClick={() => handleUpdateStatus(selectedItem.id, 'returned')}
                >
                  ✓ Mark Returned to Owner
                </button>
              </div>

              {/* Claim Submission Form */}
              <div style={{ borderTop: '1px solid #e2e8f0', paddingTop: '1.25rem' }}>
                <h4 style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a', marginBottom: '0.75rem' }}>
                  {selectedItem.type === 'found' ? 'Submit Ownership Claim' : 'Provide Information / Lead'}
                </h4>

                <form onSubmit={handleClaimSubmit}>
                  <div className="form-row">
                    <div className="form-group">
                      <label className="form-label">Your Name & Roll No.</label>
                      <input 
                        type="text" 
                        required 
                        className="form-input" 
                        placeholder="e.g. Rahul Verma (CS-22-045)"
                        value={claimName}
                        onChange={e => setClaimName(e.target.value)}
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Your Phone or Email</label>
                      <input 
                        type="text" 
                        required 
                        className="form-input" 
                        placeholder="e.g. rahul.v@campus.edu"
                        value={claimContact}
                        onChange={e => setClaimContact(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Your Answer to Challenge / Proof of Ownership</label>
                    <textarea 
                      required 
                      className="form-textarea" 
                      placeholder="Specify exact details, engravings, lockscreen photo, or marks that prove this belongs to you..."
                      value={claimProof}
                      onChange={e => setClaimProof(e.target.value)}
                    />
                  </div>

                  <button 
                    type="submit" 
                    className="btn btn-primary" 
                    style={{ width: '100%' }}
                    disabled={submittingClaim}
                  >
                    {submittingClaim ? 'Submitting Claim...' : 'Submit Claim with Proof'}
                  </button>
                </form>
              </div>

              {/* Existing Claims list */}
              {selectedItem.claims && selectedItem.claims.length > 0 && (
                <div style={{ marginTop: '1.5rem', borderTop: '1px solid #e2e8f0', paddingTop: '1rem' }}>
                  <h5 style={{ fontSize: '0.85rem', textTransform: 'uppercase', color: '#64748b', marginBottom: '0.5rem' }}>
                    Claims Received ({selectedItem.claims.length})
                  </h5>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    {selectedItem.claims.map((c, i) => (
                      <div key={i} style={{ background: '#f8fafc', padding: '0.75rem', borderRadius: '8px', fontSize: '0.85rem' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600 }}>
                          <span>{c.claimantName}</span>
                          <span style={{ color: '#64748b', fontSize: '0.75rem' }}>{new Date(c.timestamp).toLocaleString()}</span>
                        </div>
                        <div style={{ color: '#0f172a', marginTop: '0.25rem' }}>
                          <strong>Proof:</strong> {c.proofAnswer}
                        </div>
                        <div style={{ color: '#64748b', fontSize: '0.75rem', marginTop: '0.25rem' }}>
                          Contact: {c.claimantContact}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Report Item Modal */}
      {isReportOpen && (
        <div className="modal-overlay" onClick={() => setIsReportOpen(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Report Lost or Found Item</h2>
              <button className="modal-close-btn" onClick={() => setIsReportOpen(false)}>
                <X size={20} />
              </button>
            </div>

            <div className="modal-body">
              <form onSubmit={handleReportSubmit}>
                <div className="form-group">
                  <label className="form-label">Report Type</label>
                  <div style={{ display: 'flex', gap: '1rem' }}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', fontWeight: 600 }}>
                      <input 
                        type="radio" 
                        name="type" 
                        value="found"
                        checked={reportData.type === 'found'}
                        onChange={() => setReportData({ ...reportData, type: 'found' })}
                      />
                      🟢 I Found an Item
                    </label>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', fontWeight: 600 }}>
                      <input 
                        type="radio" 
                        name="type" 
                        value="lost"
                        checked={reportData.type === 'lost'}
                        onChange={() => setReportData({ ...reportData, type: 'lost' })}
                      />
                      🔴 I Lost an Item
                    </label>
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Item Title</label>
                  <input 
                    type="text" 
                    required 
                    className="form-input" 
                    placeholder="e.g. Casio fx-991EX Calculator with Blue Cover"
                    value={reportData.title}
                    onChange={e => setReportData({ ...reportData, title: e.target.value })}
                  />
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Category</label>
                    <select 
                      className="form-select"
                      value={reportData.category}
                      onChange={e => setReportData({ ...reportData, category: e.target.value })}
                    >
                      {CATEGORIES.filter(c => c !== 'All Categories').map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Campus Location</label>
                    <input 
                      type="text" 
                      required 
                      className="form-input" 
                      placeholder="e.g. Central Library 2nd Floor"
                      value={reportData.location}
                      onChange={e => setReportData({ ...reportData, location: e.target.value })}
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Date Lost / Found</label>
                    <input 
                      type="date" 
                      required 
                      className="form-input"
                      value={reportData.date}
                      onChange={e => setReportData({ ...reportData, date: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Photo Image URL (Optional)</label>
                    <input 
                      type="url" 
                      className="form-input" 
                      placeholder="https://... (or leave empty for auto image)"
                      value={reportData.presetImage}
                      onChange={e => setReportData({ ...reportData, presetImage: e.target.value })}
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Description & Circumstances</label>
                  <textarea 
                    required 
                    className="form-textarea" 
                    placeholder="Describe color, brand, condition, and where exactly it was seen or lost..."
                    value={reportData.description}
                    onChange={e => setReportData({ ...reportData, description: e.target.value })}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Security / Proof Verification Question</label>
                  <input 
                    type="text" 
                    className="form-input" 
                    placeholder="e.g. What sticker is on the back? / What is the lockscreen wallpaper?"
                    value={reportData.verificationQuestion}
                    onChange={e => setReportData({ ...reportData, verificationQuestion: e.target.value })}
                  />
                  <div className="form-helper">
                    Required for high-value items so false claimants cannot claim without proof.
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label className="form-label">Your Name</label>
                    <input 
                      type="text" 
                      required 
                      className="form-input" 
                      placeholder="e.g. Rahul Sharma"
                      value={reportData.contactName}
                      onChange={e => setReportData({ ...reportData, contactName: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Your Phone or Email</label>
                    <input 
                      type="text" 
                      required 
                      className="form-input" 
                      placeholder="e.g. rahul@student.edu"
                      value={reportData.contactInfo}
                      onChange={e => setReportData({ ...reportData, contactInfo: e.target.value })}
                    />
                  </div>
                </div>

                <button 
                  type="submit" 
                  className="btn btn-primary" 
                  style={{ width: '100%', marginTop: '0.75rem' }}
                  disabled={submittingReport}
                >
                  {submittingReport ? 'Submitting Report...' : 'Publish Report to Campus Feed'}
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Built-in Interactive Project Presentation Modal */}
      {isPresentationOpen && (
        <div className="modal-overlay" onClick={() => setIsPresentationOpen(false)}>
          <div className="presentation-modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header" style={{ borderBottomColor: '#1e293b' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <Presentation size={20} color="#38bdf8" />
                <h2 style={{ color: 'white', fontSize: '1.15rem' }}>Mini Project Viva Presentation</h2>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <a 
                  href={`${API_BASE}/presentation/download`} 
                  className="btn btn-secondary" 
                  style={{ padding: '0.4rem 0.85rem', fontSize: '0.8rem' }}
                >
                  <Download size={14} />
                  <span>Download .PPTX</span>
                </a>
                <button className="modal-close-btn" onClick={() => setIsPresentationOpen(false)}>
                  <X size={20} color="#94a3b8" />
                </button>
              </div>
            </div>

            {slides.length > 0 && (
              <div className="presentation-stage">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span className="slide-number-pill">
                    SLIDE {currentSlideIndex + 1} OF {slides.length} • {slides[currentSlideIndex].category}
                  </span>
                  <button 
                    onClick={() => setShowSpeakerNotes(!showSpeakerNotes)}
                    style={{ background: 'transparent', border: 'none', color: '#94a3b8', fontSize: '0.8rem', cursor: 'pointer', textDecoration: 'underline' }}
                  >
                    {showSpeakerNotes ? 'Hide Speaker Notes' : 'Show Speaker Notes'}
                  </button>
                </div>

                <h3 className="slide-heading">{slides[currentSlideIndex].title}</h3>
                <p className="slide-subheading">{slides[currentSlideIndex].subtitle}</p>

                <ul className="slide-bullets">
                  {slides[currentSlideIndex].bullets.map((bullet, idx) => (
                    <li key={idx} className="slide-bullet-item">
                      <div className="bullet-dot" />
                      <span>{bullet}</span>
                    </li>
                  ))}
                </ul>

                {showSpeakerNotes && (
                  <div className="speaker-notes-box">
                    <div className="speaker-notes-title">Viva Speaker Notes (What to say to evaluator):</div>
                    <div className="speaker-notes-text">
                      "{slides[currentSlideIndex].speakerNotes}"
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="presentation-footer">
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button 
                  className="btn btn-secondary"
                  disabled={currentSlideIndex === 0}
                  onClick={() => setCurrentSlideIndex(Math.max(0, currentSlideIndex - 1))}
                  style={{ opacity: currentSlideIndex === 0 ? 0.5 : 1 }}
                >
                  <ChevronLeft size={16} />
                  <span>Previous</span>
                </button>

                <button 
                  className="btn btn-primary"
                  disabled={currentSlideIndex === slides.length - 1}
                  onClick={() => setCurrentSlideIndex(Math.min(slides.length - 1, currentSlideIndex + 1))}
                  style={{ opacity: currentSlideIndex === slides.length - 1 ? 0.5 : 1 }}
                >
                  <span>Next</span>
                  <ChevronRight size={16} />
                </button>
              </div>

              {/* Slide thumbnail navigator */}
              <div style={{ display: 'flex', gap: '0.35rem', overflowX: 'auto', maxWidth: '350px' }}>
                {slides.map((s, idx) => (
                  <button
                    key={s.id}
                    onClick={() => setCurrentSlideIndex(idx)}
                    style={{
                      width: '28px',
                      height: '28px',
                      borderRadius: '6px',
                      border: idx === currentSlideIndex ? '2px solid #38bdf8' : '1px solid #334155',
                      background: idx === currentSlideIndex ? '#0284c7' : '#1e293b',
                      color: 'white',
                      fontSize: '0.75rem',
                      fontWeight: 700,
                      cursor: 'pointer'
                    }}
                  >
                    {idx + 1}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="app-footer">
        <p>
          <strong>Campus Lost & Found Platform</strong> • Full-Stack Mini Project with React + Express REST API
        </p>
        <p style={{ marginTop: '0.25rem', fontSize: '0.8rem', color: '#94a3b8' }}>
          Equipped with Dynamic Search, Ownership Challenge Verification, Real-Time Analytics, and Built-In PPTX Presentation
        </p>
      </footer>
    </div>
  );
}
