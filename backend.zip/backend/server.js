const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { createPresentation } = require('./scripts/generate_presentation');

const app = express();
const PORT = process.env.PORT || 5001;

// Middleware
app.use(cors());
app.use(express.json());

// Public static directories
const publicDir = path.join(__dirname, 'public');
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(publicDir)) fs.mkdirSync(publicDir, { recursive: true });
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

app.use('/public', express.static(publicDir));
app.use('/uploads', express.static(uploadsDir));

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1e6)}${ext}`;
    cb(null, uniqueName);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

// JSON Database Storage
const dataDir = path.join(__dirname, 'data');
const dbFile = path.join(dataDir, 'items.json');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

// Seed realistic campus lost & found items
const initialItems = [
  {
    id: "item_001",
    title: "HP Spectre 65W Laptop Charger",
    type: "found",
    category: "Electronics",
    location: "Central Library - 2nd Floor Study Room",
    date: "2026-10-14",
    description: "Found plugged into wall socket behind desk 14. Black braided cable with a slight blue tape near the adapter.",
    status: "active",
    contactName: "Rahul Sharma (Librarian)",
    contactInfo: "rahul.lib@campus.edu | Desk #3",
    verificationQuestion: "What color tape or distinctive mark is near the adapter connector?",
    imageUrl: "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=600&q=80",
    claims: [
      {
        id: "claim_001",
        claimantName: "Aditya Verma",
        claimantContact: "aditya.v@student.edu",
        proofAnswer: "Blue insulating tape wrapped 2 inches from the Type-C port.",
        timestamp: "2026-10-14T14:30:00Z",
        status: "approved"
      }
    ],
    createdAt: "2026-10-14T10:00:00Z"
  },
  {
    id: "item_002",
    title: "Student Smart Card & Bus Pass",
    type: "lost",
    category: "Cards & IDs",
    location: "Main Cafeteria / Food Court",
    date: "2026-10-15",
    description: "Lost during lunch break between 1:00 PM and 1:45 PM. Blue lanyard with CS Department emblem.",
    status: "active",
    contactName: "Priya Nair",
    contactInfo: "priya.nair@student.edu | +91 98765 43210",
    verificationQuestion: "What is the 4-digit card suffix or student roll number on the back?",
    imageUrl: "https://images.unsplash.com/photo-1589330694653-dad6bc01cf0e?auto=format&fit=crop&w=600&q=80",
    claims: [],
    createdAt: "2026-10-15T08:30:00Z"
  },
  {
    id: "item_003",
    title: "Casio fx-991EX Scientific Calculator",
    type: "found",
    category: "Books & Stationary",
    location: "Mechanical Engineering Block - Hall 204",
    date: "2026-10-13",
    description: "Found after Engineering Mathematics lecture. Black slide cover has a small sticker.",
    status: "claimed",
    contactName: "Prof. K. Sundaram",
    contactInfo: "k.sundaram@mech.campus.edu | Room 102",
    verificationQuestion: "What anime/logo sticker is on the interior of the slide case?",
    imageUrl: "https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?auto=format&fit=crop&w=600&q=80",
    claims: [
      {
        id: "claim_002",
        claimantName: "Sneha Roy",
        claimantContact: "sneha.roy@student.edu",
        proofAnswer: "Yellow Pikachu sticker on the bottom right corner.",
        timestamp: "2026-10-14T11:20:00Z",
        status: "pending"
      }
    ],
    createdAt: "2026-10-13T16:00:00Z"
  },
  {
    id: "item_004",
    title: "Apple AirPods Pro (2nd Gen) in Matte Case",
    type: "found",
    category: "Electronics",
    location: "Sports Complex & Badminton Court",
    date: "2026-10-12",
    description: "Found on the spectator bench around 6:00 PM. Olive green silicone cover.",
    status: "returned",
    contactName: "Coach Vikram Singh",
    contactInfo: "sports.office@campus.edu",
    verificationQuestion: "What initials or engraving are on the actual white AirPods case inside?",
    imageUrl: "https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?auto=format&fit=crop&w=600&q=80",
    claims: [
      {
        id: "claim_003",
        claimantName: "Rohan Gupta",
        claimantContact: "rohan.g@student.edu",
        proofAnswer: "Engraved with initials 'RG' and registered Bluetooth name is 'Rohan's Pods'.",
        timestamp: "2026-10-13T09:15:00Z",
        status: "approved"
      }
    ],
    createdAt: "2026-10-12T18:30:00Z"
  },
  {
    id: "item_005",
    title: "White Chemistry Lab Coat & Safety Goggles",
    type: "lost",
    category: "Lab & Clothing",
    location: "Chemistry Science Block - Lab 3",
    date: "2026-10-14",
    description: "Left behind on hanger row 4 after Friday afternoon organic synthesis practical.",
    status: "active",
    contactName: "Ananya Iyer",
    contactInfo: "ananya.chem@student.edu",
    verificationQuestion: "What color thread is used for the embroidered initials on the chest pocket?",
    imageUrl: "https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&w=600&q=80",
    claims: [],
    createdAt: "2026-10-14T17:10:00Z"
  },
  {
    id: "item_006",
    title: "Set of 3 Bike Keys with Iron Man Keychain",
    type: "found",
    category: "Keys & Accessories",
    location: "Two-Wheeler Parking Bay B",
    date: "2026-10-15",
    description: "Found near parking slot 45. Includes 1 Royal Enfield key, 1 disc lock key, and metal keychain.",
    status: "active",
    contactName: "Security Gate #1",
    contactInfo: "security.gate1@campus.edu | Ext: 4040",
    verificationQuestion: "What is written on the small brass tag attached to the key ring?",
    imageUrl: "https://images.unsplash.com/photo-1582139329536-e7284fece509?auto=format&fit=crop&w=600&q=80",
    claims: [],
    createdAt: "2026-10-15T09:00:00Z"
  },
  {
    id: "item_007",
    title: "Ray-Ban Matte Black Prescription Glasses",
    type: "lost",
    category: "Keys & Accessories",
    location: "Auditorium & Seminar Hall",
    date: "2026-10-13",
    description: "Lost during the Tech Symposium keynote. Rectangular frame inside a brown leather case.",
    status: "active",
    contactName: "Karthik R.",
    contactInfo: "karthik.cs@student.edu",
    verificationQuestion: "What brand cleaning cloth is inside the glasses case?",
    imageUrl: "https://images.unsplash.com/photo-1591076482161-42ce6da69f67?auto=format&fit=crop&w=600&q=80",
    claims: [],
    createdAt: "2026-10-13T12:00:00Z"
  },
  {
    id: "item_008",
    title: "Milton Stainless Steel 1000ml Water Bottle",
    type: "found",
    category: "Personal Items",
    location: "Computer Center - Lab 6",
    date: "2026-10-15",
    description: "Found beside PC 28 after Python programming lab. Brushed silver finish.",
    status: "active",
    contactName: "Lab Assistant Deepa",
    contactInfo: "lab6.cc@campus.edu",
    verificationQuestion: "What sticker or scratch pattern is on the bottom base?",
    imageUrl: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=600&q=80",
    claims: [],
    createdAt: "2026-10-15T11:45:00Z"
  }
];

function loadItems() {
  try {
    if (!fs.existsSync(dbFile)) {
      fs.writeFileSync(dbFile, JSON.stringify(initialItems, null, 2));
      return initialItems;
    }
    const raw = fs.readFileSync(dbFile, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading items database:', err);
    return initialItems;
  }
}

function saveItems(items) {
  try {
    fs.writeFileSync(dbFile, JSON.stringify(items, null, 2));
  } catch (err) {
    console.error('Error writing items database:', err);
  }
}

// -----------------------------------------------------------------
// REST API ROUTES
// -----------------------------------------------------------------

// 1. Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'Campus Lost & Found API', timestamp: new Date().toISOString() });
});

// 2. Get Items with Filters
app.get('/api/items', (req, res) => {
  const { type, category, location, status, search, sortBy } = req.query;
  let items = loadItems();

  if (type && type !== 'all') {
    items = items.filter(item => item.type.toLowerCase() === type.toLowerCase());
  }

  if (category && category !== 'all') {
    items = items.filter(item => item.category.toLowerCase() === category.toLowerCase());
  }

  if (location && location !== 'all') {
    items = items.filter(item => item.location.toLowerCase().includes(location.toLowerCase()));
  }

  if (status && status !== 'all') {
    items = items.filter(item => item.status.toLowerCase() === status.toLowerCase());
  }

  if (search && search.trim() !== '') {
    const q = search.toLowerCase().trim();
    items = items.filter(item => 
      item.title.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      item.location.toLowerCase().includes(q) ||
      item.category.toLowerCase().includes(q)
    );
  }

  // Sorting
  if (sortBy === 'oldest') {
    items.sort((a, b) => new Date(a.date) - new Date(b.date));
  } else {
    // default: newest
    items.sort((a, b) => new Date(b.date) - new Date(a.date));
  }

  res.json({
    total: items.length,
    items
  });
});

// 3. Get Single Item
app.get('/api/items/:id', (req, res) => {
  const items = loadItems();
  const item = items.find(i => i.id === req.params.id);
  if (!item) {
    return res.status(404).json({ error: 'Item not found' });
  }
  res.json(item);
});

// 4. Create New Item (with optional image upload)
app.post('/api/items', upload.single('image'), (req, res) => {
  try {
    const {
      title,
      type,
      category,
      location,
      date,
      description,
      contactName,
      contactInfo,
      verificationQuestion,
      presetImage
    } = req.body;

    if (!title || !type || !category || !location || !description || !contactName) {
      return res.status(400).json({ error: 'Missing mandatory fields' });
    }

    let imageUrl = presetImage || '';
    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
    } else if (!imageUrl) {
      // Default placeholder based on category
      const fallbacks = {
        'Electronics': 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=600&q=80',
        'Cards & IDs': 'https://images.unsplash.com/photo-1589330694653-dad6bc01cf0e?auto=format&fit=crop&w=600&q=80',
        'Books & Stationary': 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
        'Lab & Clothing': 'https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&w=600&q=80',
        'Keys & Accessories': 'https://images.unsplash.com/photo-1582139329536-e7284fece509?auto=format&fit=crop&w=600&q=80',
        'Personal Items': 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?auto=format&fit=crop&w=600&q=80'
      };
      imageUrl = fallbacks[category] || fallbacks['Personal Items'];
    }

    const items = loadItems();
    const newItem = {
      id: `item_${Date.now()}`,
      title,
      type: type.toLowerCase(),
      category,
      location,
      date: date || new Date().toISOString().split('T')[0],
      description,
      status: 'active',
      contactName,
      contactInfo: contactInfo || '',
      verificationQuestion: verificationQuestion || 'Can you describe any unique identifier or mark?',
      imageUrl,
      claims: [],
      createdAt: new Date().toISOString()
    };

    items.unshift(newItem);
    saveItems(items);

    res.status(201).json({
      message: 'Item registered successfully',
      item: newItem
    });
  } catch (error) {
    console.error('Failed to create item:', error);
    res.status(500).json({ error: 'Internal server error while saving item' });
  }
});

// 5. Submit Ownership Claim
app.post('/api/items/:id/claim', (req, res) => {
  const { claimantName, claimantContact, proofAnswer } = req.body;
  if (!claimantName || !claimantContact || !proofAnswer) {
    return res.status(400).json({ error: 'Claimant name, contact info, and proof answer are required' });
  }

  const items = loadItems();
  const index = items.findIndex(i => i.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Item not found' });
  }

  const newClaim = {
    id: `claim_${Date.now()}`,
    claimantName,
    claimantContact,
    proofAnswer,
    timestamp: new Date().toISOString(),
    status: 'pending'
  };

  items[index].claims = items[index].claims || [];
  items[index].claims.push(newClaim);
  
  if (items[index].status === 'active') {
    items[index].status = 'claimed';
  }

  saveItems(items);

  res.json({
    message: 'Claim request submitted successfully! The poster will review your proof.',
    claim: newClaim,
    item: items[index]
  });
});

// 6. Update Item Status (Active, Claimed, Returned)
app.patch('/api/items/:id/status', (req, res) => {
  const { status } = req.body;
  const validStatuses = ['active', 'claimed', 'returned'];
  if (!validStatuses.includes(status?.toLowerCase())) {
    return res.status(400).json({ error: `Status must be one of: ${validStatuses.join(', ')}` });
  }

  const items = loadItems();
  const index = items.findIndex(i => i.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Item not found' });
  }

  items[index].status = status.toLowerCase();
  saveItems(items);

  res.json({
    message: `Item status updated to ${status}`,
    item: items[index]
  });
});

// 7. Dynamic Campus Statistics & Insights
app.get('/api/stats', (req, res) => {
  const items = loadItems();

  const total = items.length;
  const activeLost = items.filter(i => i.type === 'lost' && i.status === 'active').length;
  const activeFound = items.filter(i => i.type === 'found' && i.status === 'active').length;
  const claimedCount = items.filter(i => i.status === 'claimed').length;
  const returnedCount = items.filter(i => i.status === 'returned').length;
  const recoveryRate = total > 0 ? Math.round((returnedCount / total) * 100) : 0;

  // Category counts
  const categoryStats = {};
  items.forEach(i => {
    categoryStats[i.category] = (categoryStats[i.category] || 0) + 1;
  });

  // Location counts (hotspots)
  const locationStats = {};
  items.forEach(i => {
    const locKey = i.location.split('-')[0].trim();
    locationStats[locKey] = (locationStats[locKey] || 0) + 1;
  });

  res.json({
    total,
    activeLost,
    activeFound,
    claimedCount,
    returnedCount,
    recoveryRate,
    categoryStats,
    locationStats,
    recentActivity: items.slice(0, 5).map(i => ({
      id: i.id,
      title: i.title,
      type: i.type,
      location: i.location,
      status: i.status,
      date: i.date
    }))
  });
});

// 8. Presentation Slides Data (for the built-in React Interactive Slides Deck)
app.get('/api/presentation/slides', (req, res) => {
  const slides = [
    {
      id: 1,
      title: "Smart Campus Lost & Found Hub",
      category: "Title Slide",
      subtitle: "A Dynamic Full-Stack Web Application for Automated Item Recovery & Verification",
      bullets: [
        "Tech Stack: React.js (Vite) Frontend + Node.js Express Backend REST API",
        "Problem Solved: Disorganized WhatsApp notices and lost valuable campus assets",
        "Key Differentiator: Challenge-based ownership verification & real-time analytics"
      ],
      speakerNotes: "Good morning respected evaluators. Today we present our mini project: The Smart Campus Lost and Found Hub, designed to replace chaotic campus WhatsApp messages with a structured, verified recovery workflow."
    },
    {
      id: 2,
      title: "Problem Statement & Campus Challenges",
      category: "Background & Motivation",
      subtitle: "Why Traditional Campus Lost & Found Mechanisms Fail",
      bullets: [
        "Scattered Communication: Overwhelming WhatsApp groups where notices get buried within minutes.",
        "Zero Verification: Anyone can claim found AirPods, smartcards, or calculators without proof of ownership.",
        "Lack of Centralized Search: Students cannot search by location (e.g. Library vs Cafeteria) or date.",
        "No Administrative Oversight: Campus security lacks records of unclaimed property inventory."
      ],
      speakerNotes: "On our university campus, hundreds of essential items are lost every semester. Without a structured platform, students experience unnecessary financial loss and stress."
    },
    {
      id: 3,
      title: "The Proposed Solution",
      category: "Conceptual Design",
      subtitle: "Smart, Verified, & Frictionless Campus Recovery",
      bullets: [
        "Single Source of Truth: Centralized directory for all departments, hostels, and sports facilities.",
        "Multi-Facet Dynamic Search: Instant filtering by category, location, and lost vs found status.",
        "Ownership Verification Security: Challenge question mechanism (lockscreen, engravings, roll numbers).",
        "Transparent Lifecycle: Clear status state transitions (Active -> Claim Pending -> Returned)."
      ],
      speakerNotes: "Our platform addresses this by introducing dual-sided reporting, instant faceted searching, and an anti-theft proof verification system."
    },
    {
      id: 4,
      title: "System Architecture",
      category: "Technical Architecture",
      subtitle: "Separation of Concerns: Client, REST API, & Data Engine",
      bullets: [
        "Frontend (Client): React 18 SPA bundled with Vite, responsive design, interactive modals & toast alerts.",
        "Backend (Server): Express.js REST API handling CRUD operations, image uploads with Multer, and analytics.",
        "Persistence Layer: JSON-backed storage ensuring data continuity and effortless demonstration.",
        "Presentation Engine: Built-in PPTX generator (pptxgenjs) dynamically compiling academic slide decks."
      ],
      speakerNotes: "The architecture adheres to modern web engineering principles with clean decoupled REST interfaces, fast client-side rendering, and persistent storage."
    },
    {
      id: 5,
      title: "Core Modules & Features",
      category: "System Capabilities",
      subtitle: "Comprehensive Feature Set for Students and Staff",
      bullets: [
        "1. Report Lost/Found: Intuitive modal with photo upload and custom security questions.",
        "2. Live Feed & Hotspots: Instant search with location highlighting across campus blocks.",
        "3. Claim Submission: Structured proof submission ensuring rightful owner identification.",
        "4. Live Analytics: Real-time recovery rates, category distributions, and loss hotspot trends.",
        "5. Interactive Slide Deck: Built-in presentation viewer directly integrated into the web application."
      ],
      speakerNotes: "Every feature was built with high usability in mind, allowing a student to report or claim an item in under 30 seconds."
    },
    {
      id: 6,
      title: "Security & Anti-Theft Verification",
      category: "Security Design",
      subtitle: "Preventing False Ownership Claims",
      bullets: [
        "Challenge-Question Model: The finder specifies a question only the true owner would know.",
        "Confidential Answers: Proof answers are stored securely and only accessible to the listing creator.",
        "Contact Shielding: Finder contact information is safeguarded to prevent spam.",
        "Resolution Auditing: Every claimed item creates a timestamped claim log before marking as resolved."
      ],
      speakerNotes: "A major flaw in open notice boards is anyone pretending to be the owner. Our challenge-response model effectively solves this vulnerability."
    },
    {
      id: 7,
      title: "Dynamic Analytics & Live Metrics",
      category: "Data & Metrics",
      subtitle: "Campus Recovery Performance at a Glance",
      bullets: [
        "Live Item Counter: Real-time active lost vs active found inventory.",
        "Recovery Success Rate: Dynamic formula: (Returned Items / Total Items) * 100.",
        "Category Breakdown: Electronics, Cards & IDs, Books, Lab Coats, Accessories.",
        "Campus Location Hotspots: Pinpoints high-risk loss locations (e.g. Central Library, Cafeteria)."
      ],
      speakerNotes: "The analytics engine provides administration actionable insights into campus security and high-traffic loss zones."
    },
    {
      id: 8,
      title: "Future Scope & Enhancements",
      category: "Roadmap",
      subtitle: "Expanding Beyond Basic Item Recovery",
      bullets: [
        "Computer Vision Matcher: AI image embedding to auto-match newly reported lost and found items.",
        "Campus Single Sign-On (SSO): OAuth integration with university student ID portals.",
        "Smart IoT Recovery Lockers: Automated electronic lockers in the library opened with an SMS OTP.",
        "Automated WhatsApp Bot: Instant alerts for high-priority items like lost passports or medical gear."
      ],
      speakerNotes: "For future development, the platform can be augmented with AI-powered visual similarity matching and campus biometric locker integrations."
    },
    {
      id: 9,
      title: "Testing & Validation",
      category: "Quality Assurance",
      subtitle: "Reliability & Edge Case Handling",
      bullets: [
        "REST API Validation: Form validation for missing fields and file upload boundaries.",
        "Mobile Responsiveness: Seamless UI on smartphone viewports, tablets, and desktop displays.",
        "Concurrent Claims: Handled through claim queues without data collision.",
        "User Experience Testing: Streamlined 3-click claim submission flow."
      ],
      speakerNotes: "The application was tested across multiple screen resolutions and edge cases including oversized image uploads and invalid claim requests."
    },
    {
      id: 10,
      title: "Conclusion & Project Demonstration",
      category: "Summary & Viva",
      subtitle: "Deliverables & Live Demonstration Ready",
      bullets: [
        "✓ Fully functioning, dynamic React frontend with responsive styling.",
        "✓ Robust Express.js backend with full CRUD endpoints and file handling.",
        "✓ Live data persistence and dynamic recovery statistics.",
        "✓ Downloadable 10-slide PowerPoint presentation (.pptx) generated on-demand.",
        "Ready for live demonstration and evaluator Q&A."
      ],
      speakerNotes: "In conclusion, our Smart Campus Lost & Found Hub delivers a practical, full-stack solution ready for immediate deployment. We welcome any questions from the panel."
    }
  ];

  res.json({ slides });
});

// 9. Download Presentation Endpoint (.pptx)
app.get('/api/presentation/download', async (req, res) => {
  try {
    const pptxPath = path.join(publicDir, 'Campus_Lost_and_Found_Project.pptx');
    if (!fs.existsSync(pptxPath)) {
      await createPresentation(pptxPath);
    }
    res.download(pptxPath, 'Campus_Lost_and_Found_Project.pptx');
  } catch (error) {
    console.error('Failed to download presentation:', error);
    res.status(500).json({ error: 'Could not generate PowerPoint file' });
  }
});

// Start Server
app.listen(PORT, () => {
  console.log(`🚀 Campus Lost & Found Server running at http://localhost:${PORT}`);
  console.log(`📊 API endpoints available at http://localhost:${PORT}/api/items`);
  console.log(`🎓 Presentation download at http://localhost:${PORT}/api/presentation/download`);
});
