# CampusFind: Smart Campus Lost & Found System
> **Full-Stack Mini Project with Dynamic React Frontend, Node.js/Express Backend, & PowerPoint Presentation**

---

## 📌 Executive Summary

**CampusFind** is an end-to-end, dynamic full-stack web application developed to modernize and centralize lost item reporting and recovery across college campuses. It replaces unorganized WhatsApp group chats, physical pinboards, and Instagram stories with a secure, searchable, and verified item recovery platform.

### Quick Access Links
- **Web App (Frontend)**: [http://127.0.0.1:5173/](http://127.0.0.1:5173/)
- **REST API (Backend)**: [http://localhost:5001/api/items](http://localhost:5001/api/items)
- **PowerPoint Presentation (.pptx)**: [Campus_Lost_and_Found_Project.pptx](file:///Users/sachin/.gemini/antigravity/scratch/campus-lost-and-found/Campus_Lost_and_Found_Project.pptx)
- **Project Root Directory**: [/Users/sachin/.gemini/antigravity/scratch/campus-lost-and-found/](file:///Users/sachin/.gemini/antigravity/scratch/campus-lost-and-found/)

---

## 🏛️ System Architecture

```mermaid
flowchart TD
    User["Student / Staff User"] -->|Browses & Reports| Frontend["React 19 (Vite) Single Page App"]
    Frontend -->|REST API Calls (JSON)| Backend["Node.js Express REST API (Port 5001)"]
    
    subgraph Frontend_Modules["Frontend Layer (Port 5173)"]
        Feed["Dynamic Items Feed & Search"]
        ReportModal["Report Lost/Found Modal"]
        ClaimModal["Claim & Proof Verification Modal"]
        MetricsWidget["Live Campus Analytics"]
        SlidesViewer["Built-in Presentation Viewer"]
    end
    
    subgraph Backend_Services["Backend Services"]
        Router["Express Router & Controllers"]
        Multer["Multer File & Photo Upload"]
        PptxEngine["pptxgenjs PowerPoint Engine"]
        DataStore["Atomic JSON Database Engine"]
    end
    
    Frontend --> Frontend_Modules
    Backend --> Backend_Services
    PptxEngine -->|Compiles| PPTXFile["Campus_Lost_and_Found_Project.pptx"]
```

---

## 🚀 Key Functional Modules & Dynamic Features

### 1. Dual-Sided Reporting (Lost vs Found)
- **Lost Item Posting**: Students who misplaced belongings can report detailed descriptions, location loss hotspots, and timestamps.
- **Found Item Posting**: Finders can upload photos, specify where the item was discovered, and set up an **Ownership Verification Challenge**.

### 2. Multi-Facet Instant Filtering
- **Status Filter**: `All`, `Active`, `Claim Pending`, and `Resolved / Returned`.
- **Category Filter**: `Electronics`, `Cards & IDs`, `Books & Stationary`, `Keys & Accessories`, `Lab & Clothing`, and `Personal Items`.
- **Location Filter**: `Central Library`, `Main Cafeteria`, `Computer Center`, `Mechanical Block`, `Science Block`, `Sports Complex`, etc.
- **Dynamic Keyword Search**: Instant query matching on titles, descriptions, and campus locations without page reload.

### 3. Anti-Theft Ownership Verification Challenge
> [!IMPORTANT]
> Traditional notice boards suffer from false claims. CampusFind implements a **Challenge-Response Security Mechanism**:
> - The finder specifies a question only the true owner would know (e.g., *"What wallpaper is on the lockscreen?"*, *"What initials are engraved?"*, *"What color lanyard is attached?"*).
> - The claimant must provide a valid answer along with their verified Student Roll Number and phone number before the item is handed over.

### 4. Dynamic Recovery Analytics
- **Live Metrics**: Total items reported, Active lost listings, Active found items, and Success recovery rate percentage.
- **Hotspot Tracking**: Real-time aggregation of high-risk loss locations on campus.

### 5. Dual Presentation Deck (Interactive In-App + Downloadable PPTX)
- **Interactive Presentation Mode**: A built-in modal slide deck with keyboard navigation, slide thumbnails, and **Viva Speaker Notes** explaining each slide to evaluators.
- **PowerPoint File Generator**: Automatically compiles a professional 16:9 10-slide PowerPoint presentation using `pptxgenjs`.

---

## 📡 REST API Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/items` | Query items with `search`, `type`, `category`, `location`, `status` |
| `GET` | `/api/items/:id` | Fetch item details, contact details, and submitted claims |
| `POST` | `/api/items` | Register new lost/found item report |
| `POST` | `/api/items/:id/claim` | Submit an ownership claim with challenge proof answer |
| `PATCH` | `/api/items/:id/status` | Update lifecycle status (`active`, `claimed`, `returned`) |
| `GET` | `/api/stats` | Dynamic recovery rate, category metrics, and location hotspots |
| `GET` | `/api/presentation/slides`| Retrieve 10-slide JSON deck for in-app presentation mode |
| `GET` | `/api/presentation/download`| Direct download of `Campus_Lost_and_Found_Project.pptx` |

---

## 🎓 10-Slide Presentation Deck Outline

| Slide # | Slide Title | Core Topic & Discussion Points |
| :---: | :--- | :--- |
| **01** | **Campus Lost & Found Smart Recovery** | Title, Project Scope, Tech Stack (React, Node.js, Express) |
| **02** | **Problem Statement & Campus Challenges** | Cluttered WhatsApp groups, no verification, loss of expensive assets |
| **03** | **The Proposed Solution** | Centralized web portal, verified recovery, real-time status tracking |
| **04** | **System Architecture & Tech Stack** | Decoupled client-server design, REST APIs, JSON data engine |
| **05** | **Core Modules & User Flow** | Reporting, searching, challenge verification, analytics, presentation |
| **06** | **Data Model & REST API Design** | JSON schema for items & claims, HTTP verbs, response structures |
| **07** | **Ownership Verification Workflow** | Challenge question security mechanism preventing fraudulent claims |
| **08** | **Dynamic Analytics & Impact Metrics**| Recovery rate formula, category distribution, location hotspots |
| **09** | **Future Scope & Enhancements** | AI computer vision item matching, Campus SSO, Smart IoT lockers |
| **10** | **Conclusion & Demonstration** | Project deliverables summary, live demo workflow, viva Q&A |

---

## 💻 How to Run & Present

### 1. Start Backend Server
```bash
cd /Users/sachin/.gemini/antigravity/scratch/campus-lost-and-found/backend
node server.js
```
*Backend runs on: `http://localhost:5001`*

### 2. Start React Frontend
```bash
cd /Users/sachin/.gemini/antigravity/scratch/campus-lost-and-found/frontend
npm run dev
```
*Frontend runs on: `http://127.0.0.1:5173`*

### 3. Open Presentation
- In the web app, click **"Project Presentation"** to launch the interactive in-browser slide deck with **Viva Speaker Notes**.
- Or click **"Download .PPTX"** to open [Campus_Lost_and_Found_Project.pptx](file:///Users/sachin/.gemini/antigravity/scratch/campus-lost-and-found/Campus_Lost_and_Found_Project.pptx) directly in Microsoft PowerPoint, Keynote, or Google Slides.
